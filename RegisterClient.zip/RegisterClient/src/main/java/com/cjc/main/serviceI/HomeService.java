package com.cjc.main.serviceI;

import java.util.List;

import com.cjc.main.model.Person;

public interface HomeService {

	public List<Person> getData();

	public void saveData(Person p);

	

}
