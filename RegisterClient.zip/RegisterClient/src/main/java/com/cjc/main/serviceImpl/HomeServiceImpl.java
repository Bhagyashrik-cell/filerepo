package com.cjc.main.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.main.model.Person;
import com.cjc.main.repository.HomeRepository;
import com.cjc.main.serviceI.HomeService;

@Service
public class HomeServiceImpl implements HomeService{
	@Autowired
HomeRepository hr;

	@Override
	public List<Person> getData() {
	
		return 	(List<Person>) hr.findAll();
	}

	@Override
	public void saveData(Person p) {
		hr.save(p);
		
	}

	
}
