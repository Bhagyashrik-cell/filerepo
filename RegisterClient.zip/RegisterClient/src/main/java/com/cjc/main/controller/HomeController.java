package com.cjc.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.main.model.Person;
import com.cjc.main.serviceI.HomeService;

@RestController
public class HomeController {
	@Autowired
	HomeService hs;
	@PostMapping("/postDataPerson")
public String postData(@RequestBody Person p)
{
		hs.saveData(p);
	return "post successfully";
	
}
	@GetMapping("/getData")
	public List<Person> getDataPerson()
	{
		List<Person> list=hs.getData();
		return list;
		
	}
}
